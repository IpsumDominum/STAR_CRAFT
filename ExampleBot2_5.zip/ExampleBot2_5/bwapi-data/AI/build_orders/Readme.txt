### DID YOU KNOW THAT... ###

### 1 ###
You can use multiple build order notations like:

9 - Supply Depot
11 - Barracks

or:

9/10 - Supply Depot
11/18 - Barracks

or:

SCV
SCV
SCV
SCV
Supply Depot
Barracks
Marine
Marine - x2 // Or: Marines - x2