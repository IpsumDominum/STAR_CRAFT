package atlantis.production.requests;

import atlantis.position.APosition;

/**
 *
 * @author Rafal Poniatowski <ravaelles@gmail.com>
 */
public class ProtossRequests extends ARequests {

    @Override
    public void requestDetectorQuick(APosition where) {
        
    }

    @Override
    public void requestAntiAirQuick(APosition where) {
        
    }
    
}
