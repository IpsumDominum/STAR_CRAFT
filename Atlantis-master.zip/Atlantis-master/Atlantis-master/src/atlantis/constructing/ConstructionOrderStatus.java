package atlantis.constructing;

public enum ConstructionOrderStatus {

	CONSTRUCTION_NOT_STARTED, CONSTRUCTION_IN_PROGRESS, CONSTRUCTION_FINISHED

}
